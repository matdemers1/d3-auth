#!/usr/bin/env node
/**
 * The rules the audit exists because nobody was enforcing.
 *
 * Phase 0 counted 176 distinct colour values, 18 blues, 19 type sizes and 170
 * button recipes across five apps. None of that was carelessness — it is what
 * happens when the only thing standing between a developer and a raw hex is a
 * convention written down somewhere. So this is a gate, not a guideline.
 *
 *   npx d3-check-usage [--tailwind] <dir> [<dir>…]
 *
 * `--tailwind` is for apps that compile their CSS through Tailwind v4 with the
 * system's theme.css: it admits the `@theme` names as well as the runtime ones.
 *
 * It ships inside the package rather than beside the design record, because a
 * gate that lives in a sibling directory is a gate that fails in CI: Bindery's
 * lint called it across repositories and its build went red on the first push.
 *
 * Scans .ts/.tsx/.js/.jsx/.css. Anything genuinely exceptional carries
 * `d3-allow: <reason>` in a comment on the same line or the line above — the
 * reason is required, so an exemption is a decision somebody wrote down rather
 * than a line quietly added to this file.
 */
import { readdirSync, readFileSync, statSync } from 'node:fs'
import { join, extname, relative, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

const PALETTE =
  'slate|gray|grey|zinc|neutral|stone|red|orange|amber|yellow|lime|green|emerald|' +
  'teal|cyan|sky|blue|indigo|violet|purple|fuchsia|pink|rose'
const UTIL =
  'bg|text|border|ring|from|to|via|fill|stroke|divide|outline|decoration|accent|' +
  'caret|placeholder|shadow'

const RULES = [
  { id: 'raw-hex',
    re: /#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})\b/g,
    css: true, js: true,
    say: 'a raw hex colour. Use a semantic token — this is the single habit that produced 176 colour values.' },

  { id: 'palette-class',
    re: new RegExp(`\\b(?:${UTIL})-(?:${PALETTE})-\\d{2,3}\\b`, 'g'),
    css: false, js: true,
    say: "a raw Tailwind palette class. The system's colours are semantic: bg-surface, text-muted, border-field." },

  // Only the scales the system actually owns. The first version of this rule
  // flagged every arbitrary value, which meant `grid-cols-[1fr_22rem]` and
  // `max-h-[80vh]` — a layout template and a viewport height, neither of which
  // the system has an opinion about. A gate that reports 73 things when 42 are
  // real is a gate people learn to skip, which is the same failure the Phase 2
  // contrast matrix had.
  { id: 'off-scale-value',
    re: new RegExp(
      String.raw`\b(?:text|leading|tracking|font|rounded|` +
      String.raw`[pm][xytrbl]?|gap(?:-[xy])?|space-[xy])` +
      // …and only for a fixed length. vh/vw/%/calc/fr are not on any scale here.
      String.raw`-\[(?![^\]]*(?:vh|vw|%|calc|fr|auto))[^\]\s]+\]`, 'g'),
    css: false, js: true,
    say: 'an off-scale value on a scale the system owns (type, spacing, radius, weight). ' +
         'If the scale has no step for it, the scale is the thing to change — not the call site.' },

  { id: 'primitive-token',
    re: /var\(\s*--p-[\w-]+/g,
    css: true, js: true,
    say: 'a primitive token. Primitives are exposed for tooling only; components read semantic tokens.' },

  { id: 'shadow',
    // `box-shadow: none` is the rule being enforced, not broken — the library
    // writes it explicitly on Card, Modal, Select and Tooltip. `inset` is a ring
    // drawn inside a control (a pressed toggle), which is a boundary, not lift.
    re: /\bshadow-(?!none\b)[a-z0-9-]+\b|box-shadow\s*:(?!\s*none\b)(?![^;]*inset)/g,
    css: true, js: true,
    say: 'a shadow. Elevation in this system is tone, and detachment is a boundary (D-015).' },
]

const args = process.argv.slice(2)
// --tailwind: the app compiles its CSS through Tailwind v4 with the system's
// theme.css, so the names declared in its `@theme` blocks are admitted too.
const TAILWIND = args.includes('--tailwind')
const dirs = args.filter((a) => !a.startsWith('--'))
if (!dirs.length) { console.error('usage: check-usage.mjs [--tailwind] <dir> [<dir>…]'); process.exit(2) }

// Every custom property the system defines, read from the package's own token
// stylesheets — so a consumer checks against the tokens it actually installed.
//
// Only RUNTIME declarations count by default. The theme*.css files declare
// Tailwind's names (`--font-weight-title`, `--text-24--line-height`) inside
// `@theme inline`, which is an instruction to the Tailwind compiler and emits
// no custom property a browser can read. The first version of this rule read
// every declaration in every file, so the D3 Auth console — no Tailwind — used
// both names, passed the gate, and rendered every heading at weight 400.
const TOKEN_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', 'src', 'tokens', 'build')
const SYSTEM_NAMESPACES = /^--(color|space|radius|text|leading|weight|font|motion|ease|dur|icon|border|focus|container|scrim)-/

/**
 * Splits a stylesheet's custom-property declarations into those a browser sees
 * and those inside an `@theme` block, which only Tailwind's compiler sees.
 */
function readTokenDeclarations(css) {
  const runtime = new Set()
  const theme = new Set()
  const source = css.replace(/\/\*[\s\S]*?\*\//g, (c) => c.replace(/[^\n]/g, ' '))
  // Mark the character ranges that sit inside an @theme block, by brace depth.
  const ranges = []
  for (const m of source.matchAll(/@theme\b[^{;]*\{/g)) {
    let depth = 1
    let i = m.index + m[0].length
    for (; i < source.length && depth > 0; i++) {
      if (source[i] === '{') depth++
      else if (source[i] === '}') depth--
    }
    ranges.push([m.index, i])
  }
  for (const m of source.matchAll(/(--[\w-]+)\s*:/g)) {
    const inTheme = ranges.some(([a, b]) => m.index >= a && m.index < b)
    ;(inTheme ? theme : runtime).add(m[1])
  }
  return { runtime, theme }
}

const systemTokens = new Set()
const tailwindTokens = new Set()
try {
  for (const f of readdirSync(TOKEN_DIR).filter((f) => f.endsWith('.css'))) {
    const { runtime, theme } = readTokenDeclarations(readFileSync(join(TOKEN_DIR, f), 'utf8'))
    for (const t of runtime) systemTokens.add(t)
    for (const t of theme) tailwindTokens.add(t)
  }
} catch { /* tokens missing — the unknown-token rule below will say so */ }
if (TAILWIND) for (const t of tailwindTokens) systemTokens.add(t)

const UNKNOWN_TOKEN = {
  id: 'unknown-token',
  say: 'a system token that does not exist. If it was renamed, use the new name — an undefined custom property fails silently.',
}
const TAILWIND_ONLY_TOKEN = {
  id: 'tailwind-only-token',
  say: 'a Tailwind theme name, declared only inside `@theme` — it does not exist at runtime without Tailwind. ' +
       'Use the runtime token (`--weight-*`, `--leading-*`), or run with --tailwind if this app compiles through Tailwind v4.',
}

const SKIP = new Set(['node_modules', 'dist', 'build', '.git', 'coverage', '.next', 'storybook-static'])
const TEST_FILE = /\.(test|spec)\.[jt]sx?$/

function* walk(dir) {
  for (const entry of readdirSync(dir)) {
    if (SKIP.has(entry)) continue
    const p = join(dir, entry)
    if (statSync(p).isDirectory()) yield* walk(p)
    // Tests are skipped: a fixture's `fgColor: '#000000'` is data under test,
    // not a colour anyone sees. d3-qr's QR and PDF tests were 17 of its 30
    // findings, and exempting every fixture line teaches people to exempt.
    else if (TEST_FILE.test(entry)) continue
    else if (['.ts', '.tsx', '.js', '.jsx', '.css'].includes(extname(p))) yield p
  }
}

// Custom properties the app declares for itself — a bridge alias like
// `--color-ink`, or an app-local token like `--color-mark` — are not errors.
const localTokens = new Set()
for (const dir of dirs) {
  for (const file of walk(dir)) {
    for (const m of readFileSync(file, 'utf8').matchAll(/(--[\w-]+)\s*:/g)) localTokens.add(m[1])
  }
}

const findings = []
let allowed = 0
let scanned = 0
for (const dir of dirs) {
  for (const file of walk(dir)) {
    scanned++
    const isCss = extname(file) === '.css'
    const lines = readFileSync(file, 'utf8').split('\n')
    // Which lines are inside a comment, block or line. One pass, so the
    // lookback above can ask instead of guess.
    const inComment = []
    let open = false
    for (const l of lines) {
      const startsOpen = open
      let scan = l
      while (true) {
        if (!open) {
          const a = scan.indexOf('/*')
          if (a === -1) break
          open = true; scan = scan.slice(a + 2)
        } else {
          const b = scan.indexOf('*/')
          if (b === -1) break
          open = false; scan = scan.slice(b + 2)
        }
      }
      inComment.push(startsOpen || open || /^\s*(?:\/\/|\{?\/\*)/.test(l) || /\*\//.test(l))
    }
    lines.forEach((line, i) => {
      // Look back through the comment block this line sits under. Detecting the
      // block properly rather than pattern-matching line prefixes: a reason worth
      // stating usually wraps, and continuation lines have no leading marker, so
      // a prefix test silently stops applying the moment somebody reflows a
      // sentence — an exemption mechanism that fails quietly is worse than none.
      const exempt = (() => {
        if (/d3-allow:\s*\S/.test(line)) return true
        for (let j = i - 1; j >= 0 && i - j <= 10; j--) {
          if (/d3-allow:\s*\S/.test(lines[j])) return true
          if (!inComment[j]) return false
        }
        return false
      })()
      // A reference to a system token that does not exist — the failure a token
      // rename causes, and one no type-checker or linter sees: the property is
      // simply undefined, and the colour falls back to inherited without a word.
      if (systemTokens.size && !exempt) {
        for (const m of line.matchAll(/var\(\s*(--[\w-]+)/g)) {
          const name = m[1]
          if (SYSTEM_NAMESPACES.test(name) && !systemTokens.has(name) && !localTokens.has(name)) {
            const rule = tailwindTokens.has(name) ? TAILWIND_ONLY_TOKEN : UNKNOWN_TOKEN
            findings.push({ file, line: i + 1, rule, hits: [name] })
          }
        }
      }
      for (const rule of RULES) {
        if (isCss ? !rule.css : !rule.js) continue
        rule.re.lastIndex = 0
        const hits = line.match(rule.re)
        if (!hits) continue
        if (exempt) { allowed += hits.length; continue }
        findings.push({ file, line: i + 1, rule, hits: [...new Set(hits)] })
      }
    })
  }
}

const byRule = new Map()
for (const f of findings) byRule.set(f.rule.id, [...(byRule.get(f.rule.id) ?? []), f])

if (!findings.length) {
  console.log(`  usage ok — ${scanned} files, no violations` +
              (allowed ? `, ${allowed} exemption(s) with a stated reason.` : '.'))
  process.exit(0)
}
console.error(`\n  ${findings.length} usage violation(s) across ${scanned} files:\n`)
for (const [id, list] of byRule) {
  console.error(`  ${id} — ${list[0].rule.say}`)
  for (const f of list.slice(0, 12)) {
    console.error(`     ${relative(process.cwd(), f.file)}:${f.line}  ${f.hits.join(' ')}`)
  }
  if (list.length > 12) console.error(`     … and ${list.length - 12} more`)
  console.error('')
}
process.exit(1)
